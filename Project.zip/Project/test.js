class MyClass
{
	constructor()
	{
		this.n = 0;
	}
	factorial(n)
	{
		if(n == 1)
			return 1;
		else
			return n * this.factorial(n - 1);
	}
	main(args)
	{
		this.n = 10;
		console.log("abd
		cabsd");
	}
}
var main = new MyClass();
main = main.main();
